from fastapi import FastAPI, Request, Query
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
from fastapi.responses import JSONResponse
from fastapi import Depends
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from fastapi import HTTPException, status
import openai
from typing import List

# Create a FastAPI instance
application = FastAPI()

# Configure FastAPI to serve static files (e.g., CSS and JavaScript)
application.mount("/static", StaticFiles(directory="static"), name="static")

# Set your OpenAI API key here
openai.api_key = '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'

# Create a session variable for chat history (in-memory storage)
chat_history = []

# Configure templates directory for Jinja2
templates = Jinja2Templates(directory="templates")

# Route for the chat page
@application.get("/")
async def chat(request: Request):
    return templates.TemplateResponse("chat1.html", {"request": request})

# Route for getting bot responses
@application.get("/get_response/")
async def get_response(user_input: str = Query(None)):
    if user_input.strip() == "":
        return JSONResponse(content={"response": "Please enter a message."})

    global chat_history
    chat_history.append({'role': 'user', 'content': user_input})
    chat_history_string = "\n".join(f"{msg['role']}: {msg['content']}" for msg in chat_history)
    print('################',user_input)
    try:
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "You are a helpful assistant."},
                {"role": "user", "content": user_input}
            ]
        )
        bot_response = response['choices'][0]['message']['content']
    except Exception as e:
        bot_response = str(e)

    chat_history.append({'role': 'bot', 'content': bot_response})

    return JSONResponse(content={"response": bot_response})

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(application, host="0.0.0.0", port=8000)
